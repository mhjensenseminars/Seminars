This IPython notebook NPCompetences.ipynb does not require any additional
programs.
