This IPython notebook NPretreatComputation.ipynb does not require any additional
programs.
