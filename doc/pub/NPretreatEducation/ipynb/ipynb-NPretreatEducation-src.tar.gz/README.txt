This IPython notebook NPretreatEducation.ipynb does not require any additional
programs.
