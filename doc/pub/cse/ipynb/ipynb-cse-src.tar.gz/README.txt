This IPython notebook cse.ipynb does not require any additional
programs.
