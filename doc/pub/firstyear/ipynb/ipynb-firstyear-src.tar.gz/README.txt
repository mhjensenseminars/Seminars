This IPython notebook firstyear.ipynb does not require any additional
programs.
