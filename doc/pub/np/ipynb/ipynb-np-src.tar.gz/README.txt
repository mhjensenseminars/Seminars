This IPython notebook np.ipynb does not require any additional
programs.
