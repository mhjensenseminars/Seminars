This IPython notebook questions.ipynb does not require any additional
programs.
