This IPython notebook uioedu.ipynb does not require any additional
programs.
