This IPython notebook utdanningskonf.ipynb does not require any additional
programs.
