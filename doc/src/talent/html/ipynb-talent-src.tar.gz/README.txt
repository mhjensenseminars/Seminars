This IPython notebook talent.ipynb does not require any additional
programs.
